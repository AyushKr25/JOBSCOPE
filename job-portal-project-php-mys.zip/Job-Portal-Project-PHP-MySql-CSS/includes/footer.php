<div class="footer-copyright-item">
  <div class="container">
    <p>This website is coded by Md. Sabbir Hosen &copy; <script>
        const date = new Date();
        const year = date.getFullYear();
        document.write(year);
      </script> All Rights Reserved
    </p>
  </div>
</div>